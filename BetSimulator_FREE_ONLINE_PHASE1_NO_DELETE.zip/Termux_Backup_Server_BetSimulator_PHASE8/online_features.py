"""
BetSimulator Phase 8 - server-side online features.

This module is intentionally standard-library-only and is loaded by server.py.
It owns the user-facing non-game feature APIs that are not part of the small
core server. Games remain separate and authoritative in server.py.

Design goals:
- server-authoritative state; no demo fixtures
- idempotent mutations where money/state can change
- SQLite only, no external Python dependencies
- safe empty responses for provider-backed Sports/Live when no provider exists
- preserve existing Phase 8 database files through additive migrations
"""

import hashlib
import json
import os
import secrets
import sqlite3
import time
from typing import Any, Dict, Optional


def _now() -> int:
    return int(time.time())


def _db():
    # server.py passes its db function into init_schema; kept replaceable here
    raise RuntimeError("online_features database provider is not initialized")


_DB_PROVIDER = None


def _set_db(provider):
    global _DB_PROVIDER
    _DB_PROVIDER = provider


def db():
    if _DB_PROVIDER is None:
        raise RuntimeError("online_features database provider is not initialized")
    # Use a lightweight connection here instead of server.py's helper. The core
    # helper executes PRAGMA journal_mode=WAL on every connection; doing that
    # while this module still has a transaction/connection open can serialize a
    # response path. WAL is already enabled by the core database initializer.
    try:
        import server
        c = sqlite3.connect(server.DB_PATH, timeout=15)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=ON")
        return c
    except Exception:
        return _DB_PROVIDER()


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _body(handler) -> Dict[str, Any]:
    try:
        n = int(handler.headers.get("Content-Length", "0"))
        raw = handler.rfile.read(n).decode("utf-8") if n else "{}"
        value = json.loads(raw or "{}")
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _auth(handler):
    # Use the core server's authoritative auth helper. server.py imports this
    # module after defining get_user, so lazy lookup avoids circular imports.
    try:
        import server
        return server.get_user(handler)
    except Exception:
        return None


def _audit(handler, user, action: str, detail: str = ""):
    try:
        import server
        server.API.audit(handler, user, action, detail)
    except Exception:
        try:
            c = db()
            c.execute(
                "INSERT INTO audit_log(actor_user_id,action,detail,created_at) VALUES(?,?,?,?)",
                (user["id"] if user else None, action, detail, _now()),
            )
            c.commit()
            c.close()
        except Exception:
            pass


def _idempotent(user_id: int, key: str):
    if not key:
        return None
    c = db()
    row = c.execute(
        "SELECT response FROM idempotency WHERE user_id=? AND key=?",
        (user_id, key),
    ).fetchone()
    c.close()
    if not row:
        return None
    try:
        return json.loads(row["response"])
    except Exception:
        return {"ok": True, "replayed": True}


def _save_idempotent(c, user_id: int, key: str, response: Dict[str, Any]):
    if key:
        c.execute(
            "INSERT OR IGNORE INTO idempotency(user_id,key,response,created_at) VALUES(?,?,?,?)",
            (user_id, key, _json(response), _now()),
        )


def _ensure(c, sql: str):
    c.execute(sql)


def init_schema(db_provider):
    """Called by server.py after its core schema is initialized."""
    _set_db(db_provider)
    c = db()
    c.executescript(
        """
        CREATE TABLE IF NOT EXISTS user_settings(
            user_id INTEGER PRIMARY KEY,
            settings TEXT NOT NULL DEFAULT '{}',
            updated_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS reward_catalog(
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            amount INTEGER NOT NULL DEFAULT 0,
            points INTEGER NOT NULL DEFAULT 0,
            available_at INTEGER NOT NULL DEFAULT 0,
            enabled INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS reward_claims(
            user_id INTEGER NOT NULL,
            reward_id TEXT NOT NULL,
            claimed_at INTEGER NOT NULL,
            PRIMARY KEY(user_id,reward_id)
        );
        CREATE TABLE IF NOT EXISTS shop_ownership(
            user_id INTEGER NOT NULL,
            item_id TEXT NOT NULL,
            equipped INTEGER NOT NULL DEFAULT 0,
            purchased_at INTEGER NOT NULL,
            PRIMARY KEY(user_id,item_id)
        );
        CREATE TABLE IF NOT EXISTS social_messages(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            message TEXT NOT NULL,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS chat_messages(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            username TEXT NOT NULL,
            message TEXT NOT NULL,
            mine INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS support_tickets(
            id TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            subject TEXT NOT NULL,
            body TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'OPEN',
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS protection_settings(
            user_id INTEGER PRIMARY KEY,
            self_excluded_until INTEGER NOT NULL DEFAULT 0,
            daily_deposit_limit INTEGER NOT NULL DEFAULT 0,
            updated_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS staking_positions(
            id TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            amount INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'ACTIVE',
            created_at INTEGER NOT NULL,
            unstaked_at INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS server_backups(
            id TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            created_at INTEGER NOT NULL,
            checksum TEXT NOT NULL,
            payload TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS api_provider_config(
            name TEXT PRIMARY KEY,
            config TEXT NOT NULL DEFAULT '{}',
            updated_at INTEGER NOT NULL
        );
        """
    )
    # No fake reward/shop records are inserted here. Existing server.py shop
    # records remain available and are considered authoritative.
    c.commit()
    c.close()


def _require(handler):
    user = _auth(handler)
    if not user:
        handler.send_json(401, {"error": "UNAUTHORIZED"})
        return None
    return user


def _user_settings(c, uid: int) -> Dict[str, Any]:
    row = c.execute("SELECT settings FROM user_settings WHERE user_id=?", (uid,)).fetchone()
    if not row:
        return {}
    try:
        value = json.loads(row["settings"])
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _wallet_balance(c, uid: int) -> int:
    row = c.execute("SELECT balance FROM users WHERE id=?", (uid,)).fetchone()
    return int(row["balance"] if row else 0)


def _protection(c, uid: int):
    row = c.execute("SELECT * FROM protection_settings WHERE user_id=?", (uid,)).fetchone()
    if not row:
        return {"selfExcluded": False, "selfExcludedUntil": 0, "dailyDepositLimit": 0}
    return {
        "selfExcluded": int(row["self_excluded_until"]) > _now(),
        "selfExcludedUntil": int(row["self_excluded_until"]),
        "dailyDepositLimit": int(row["daily_deposit_limit"]),
    }


def _blocked_by_protection(c, uid: int) -> Optional[str]:
    p = _protection(c, uid)
    if p["selfExcluded"]:
        return "SELF_EXCLUDED"
    return None


def _vip(c, uid: int) -> Dict[str, Any]:
    row = c.execute("SELECT points,vip_level FROM rewards WHERE user_id=?", (uid,)).fetchone()
    points = int(row["points"] if row else 0)
    stored = int(row["vip_level"] if row else 0)
    level = max(stored, points // 1000)
    tiers = [(0, "BRONZE"), (1, "SILVER"), (3, "GOLD"), (5, "PLATINUM"), (10, "DIAMOND")]
    tier = "BRONZE"
    current_threshold = 0
    next_threshold = 1000
    for threshold, name in tiers:
        if level >= threshold:
            tier = name
            current_threshold = threshold * 1000
    for threshold, _ in tiers:
        if threshold > level:
            next_threshold = threshold * 1000
            break
    else:
        next_threshold = max(points + 1000, 11000)
    span = max(1, next_threshold - current_threshold)
    progress = int(max(0, min(100, (points - current_threshold) * 100 / span)))
    benefits = []
    if level >= 1:
        benefits.append({"type": "VIP tier", "value": tier})
    if level >= 3:
        benefits.append({"type": "Reward multiplier", "value": "1.10x"})
    if level >= 5:
        benefits.append({"type": "Priority support", "value": "Enabled"})
    return {"tier": tier, "level": level, "xp": points, "progress": progress, "benefits": benefits}


def _analytics(c, uid: int) -> Dict[str, Any]:
    played = int(c.execute("SELECT COUNT(*) n FROM game_rounds WHERE user_id=?", (uid,)).fetchone()["n"])
    wagered = int(c.execute("SELECT COALESCE(SUM(stake),0) n FROM game_rounds WHERE user_id=?", (uid,)).fetchone()["n"])
    won = int(c.execute("SELECT COALESCE(SUM(payout),0) n FROM game_rounds WHERE user_id=?", (uid,)).fetchone()["n"])
    deposits = int(c.execute("SELECT COALESCE(SUM(amount),0) n FROM wallet_ledger WHERE user_id=? AND type='DEPOSIT'", (uid,)).fetchone()["n"])
    withdrawals = int(c.execute("SELECT COALESCE(SUM(-amount),0) n FROM wallet_ledger WHERE user_id=? AND type='WITHDRAW'", (uid,)).fetchone()["n"])
    return {"played": played, "wagered": wagered, "won": won, "deposited": deposits, "withdrawn": withdrawals}


def _sports_response(c):
    # Provider-backed data only. Do not manufacture fixtures/odds.
    row = c.execute("SELECT config FROM api_provider_config WHERE name='sports'").fetchone()
    if not row:
        return {"events": [], "source": "server", "providerConfigured": False}
    try:
        cfg = json.loads(row["config"])
    except Exception:
        cfg = {}
    events = cfg.get("events") if isinstance(cfg, dict) else []
    return {"events": events if isinstance(events, list) else [], "source": "provider", "providerConfigured": True}


def _live_response(c):
    row = c.execute("SELECT config FROM api_provider_config WHERE name='live'").fetchone()
    if not row:
        return {"events": [], "source": "server", "providerConfigured": False}
    try:
        cfg = json.loads(row["config"])
    except Exception:
        cfg = {}
    events = cfg.get("events") if isinstance(cfg, dict) else []
    return {"events": events if isinstance(events, list) else [], "source": "provider", "providerConfigured": True}


def deposit_block(c, user_id: int, amount: int):
    """Return (HTTP status, error) when a deposit is blocked, else None."""
    row = c.execute("SELECT self_excluded_until,daily_deposit_limit FROM protection_settings WHERE user_id=?", (user_id,)).fetchone()
    now = _now()
    if row and int(row["self_excluded_until"]) > now:
        return (409, "SELF_EXCLUDED")
    limit = int(row["daily_deposit_limit"] if row else 0)
    if limit > 0:
        day_start = now - (now % 86400)
        used = c.execute(
            "SELECT COALESCE(SUM(amount),0) n FROM wallet_ledger WHERE user_id=? AND type='DEPOSIT' AND created_at>=?",
            (user_id, day_start),
        ).fetchone()["n"]
        if int(used) + int(amount) > limit:
            return (409, "DEPOSIT_LIMIT_EXCEEDED")
    return None


def spend_block(c, user_id: int):
    """Return (HTTP status, error) when a money-spending action is blocked."""
    row = c.execute("SELECT self_excluded_until FROM protection_settings WHERE user_id=?", (user_id,)).fetchone()
    if row and int(row["self_excluded_until"]) > _now():
        return (409, "SELF_EXCLUDED")
    return None


def _handle_get(handler, p: str):
    owned = {
        "/v1/rewards", "/v1/shop", "/v1/social", "/v1/vip", "/v1/sports",
        "/v1/analytics", "/v1/live", "/v1/chat", "/v1/staking",
        "/v1/support", "/v1/protection", "/v1/settings", "/v1/backup",
    }
    if p not in owned:
        return False
    u = _require(handler)
    if not u:
        return True
    c = db()
    uid = int(u["id"])
    try:
        if p == "/v1/rewards":
            rows = c.execute("SELECT * FROM reward_catalog WHERE enabled=1 ORDER BY available_at,id").fetchall()
            claims = {r["reward_id"] for r in c.execute("SELECT reward_id FROM reward_claims WHERE user_id=?", (uid,)).fetchall()}
            rewards = []
            for r in rows:
                rewards.append({"id": r["id"], "title": r["title"], "amount": r["amount"], "points": r["points"], "availableAt": r["available_at"], "claimed": r["id"] in claims})
            points = c.execute("SELECT points FROM rewards WHERE user_id=?", (uid,)).fetchone()
            handler.send_json(200, {"points": int(points["points"] if points else 0), "rewards": rewards})
            return True

        if p == "/v1/shop":
            rows = c.execute("SELECT * FROM shop_items WHERE enabled=1 ORDER BY name").fetchall()
            owned = {r["item_id"]: r for r in c.execute("SELECT * FROM shop_ownership WHERE user_id=?", (uid,)).fetchall()}
            items = []
            for r in rows:
                o = owned.get(r["id"])
                items.append({"id": r["id"], "name": r["name"], "price": r["price"], "category": "ITEM", "perk": "Server configured", "owned": bool(o), "equipped": bool(o and o["equipped"])})
            handler.send_json(200, {"balance": _wallet_balance(c, uid), "items": items})
            return True

        if p == "/v1/social":
            following = c.execute("SELECT COUNT(*) n FROM social_follows WHERE user_id=?", (uid,)).fetchone()["n"]
            followers = c.execute("SELECT COUNT(*) n FROM social_follows WHERE target_user_id=?", (uid,)).fetchone()["n"]
            rows = c.execute("SELECT id,username FROM users WHERE id<>? AND status='ACTIVE' ORDER BY username LIMIT 100", (uid,)).fetchall()
            followed = {r["target_user_id"] for r in c.execute("SELECT target_user_id FROM social_follows WHERE user_id=?", (uid,)).fetchall()}
            users = [{"id": r["id"], "username": r["username"], "following": r["id"] in followed} for r in rows]
            handler.send_json(200, {"followingCount": int(following), "followerCount": int(followers), "users": users})
            return True

        if p == "/v1/vip":
            handler.send_json(200, _vip(c, uid))
            return True

        if p == "/v1/sports":
            handler.send_json(200, _sports_response(c))
            return True

        if p == "/v1/analytics":
            handler.send_json(200, _analytics(c, uid))
            return True

        if p == "/v1/live":
            handler.send_json(200, _live_response(c))
            return True

        if p == "/v1/chat":
            rows = c.execute("SELECT id,username,message,mine,created_at FROM chat_messages WHERE user_id=? ORDER BY id DESC LIMIT 100", (uid,)).fetchall()
            messages = [dict(id=r["id"], username=r["username"], message=r["message"], mine=bool(r["mine"]), created_at=r["created_at"]) for r in reversed(rows)]
            handler.send_json(200, {"messages": messages})
            return True

        if p == "/v1/staking":
            rows = c.execute("SELECT * FROM staking_positions WHERE user_id=? ORDER BY created_at DESC", (uid,)).fetchall()
            handler.send_json(200, {"positions": [dict(id=r["id"], amount=r["amount"], status=r["status"], createdAt=r["created_at"], unstakedAt=r["unstaked_at"]) for r in rows], "totalStaked": sum(int(r["amount"]) for r in rows if r["status"] == "ACTIVE")})
            return True

        if p == "/v1/support":
            rows = c.execute("SELECT * FROM support_tickets WHERE user_id=? ORDER BY created_at DESC", (uid,)).fetchall()
            handler.send_json(200, {"tickets": [dict(id=r["id"], subject=r["subject"], body=r["body"], status=r["status"], createdAt=r["created_at"], updatedAt=r["updated_at"]) for r in rows]})
            return True

        if p == "/v1/protection":
            handler.send_json(200, _protection(c, uid))
            return True

        if p == "/v1/settings":
            handler.send_json(200, {"settings": _user_settings(c, uid)})
            return True

        if p == "/v1/backup":
            rows = c.execute("SELECT id,created_at,checksum FROM server_backups WHERE user_id=? ORDER BY created_at DESC LIMIT 10", (uid,)).fetchall()
            handler.send_json(200, {"scope": "account", "max": 10, "backups": [{"id": r["id"], "createdAt": r["created_at"], "checksum": r["checksum"]} for r in rows]})
            return True

        return False
    finally:
        c.close()


def _handle_post(handler, p: str, q: Dict[str, Any]):
    owned = {
        "/v1/rewards/claim", "/v1/shop/purchase", "/v1/shop/equip",
        "/v1/social/follow", "/v1/social/unfollow", "/v1/staking/stake",
        "/v1/staking/unstake", "/v1/support/tickets", "/v1/protection",
        "/v1/backup", "/v1/backup/restore", "/v1/chat", "/v1/ai",
    }
    if p not in owned:
        return False
    u = _require(handler)
    if not u:
        return True
    c = db()
    uid = int(u["id"])
    try:
        if p == "/v1/rewards/claim":
            rid = str(q.get("rewardId", "")).strip()
            if not rid:
                handler.send_json(400, {"error": "INVALID_REWARD"}); return True
            row = c.execute("SELECT * FROM reward_catalog WHERE id=? AND enabled=1", (rid,)).fetchone()
            if not row:
                handler.send_json(404, {"error": "REWARD_NOT_FOUND"}); return True
            if int(row["available_at"]) > _now():
                handler.send_json(409, {"error": "REWARD_NOT_READY"}); return True
            if c.execute("SELECT 1 FROM reward_claims WHERE user_id=? AND reward_id=?", (uid, rid)).fetchone():
                handler.send_json(409, {"error": "REWARD_ALREADY_CLAIMED"}); return True
            blocked = _blocked_by_protection(c, uid)
            if blocked:
                handler.send_json(409, {"error": blocked}); return True
            now = _now(); c.execute("INSERT INTO reward_claims VALUES(?,?,?)", (uid, rid, now))
            c.execute("INSERT OR IGNORE INTO rewards(user_id,points,vip_level) VALUES(?,0,0)", (uid,))
            c.execute("UPDATE rewards SET points=points+? WHERE user_id=?", (row["points"], uid))
            amount = int(row["amount"])
            if amount:
                bal = _wallet_balance(c, uid) + amount
                c.execute("UPDATE users SET balance=?,last_active=? WHERE id=?", (bal, now, uid))
                c.execute("INSERT INTO wallet_ledger(user_id,type,amount,balance_after,reference,created_at,idempotency_key) VALUES(?,?,?,?,?,?,?)", (uid, "REWARD", amount, bal, "reward:" + rid, now, "reward:%d:%s" % (uid, rid)))
            c.commit(); _audit(handler, u, "REWARD_CLAIM", rid)
            handler.send_json(200, {"ok": True, "rewardId": rid, "amount": amount, "points": int(row["points"])})
            return True

        if p == "/v1/shop/purchase":
            iid = str(q.get("itemId", "")).strip(); key = str(q.get("idempotencyKey", "")).strip()
            replay = _idempotent(uid, key)
            if replay is not None:
                replay["replayed"] = True; handler.send_json(200, replay); return True
            item = c.execute("SELECT * FROM shop_items WHERE id=? AND enabled=1", (iid,)).fetchone()
            if not item: handler.send_json(404, {"error": "ITEM_NOT_FOUND"}); return True
            if c.execute("SELECT 1 FROM shop_ownership WHERE user_id=? AND item_id=?", (uid, iid)).fetchone(): handler.send_json(409, {"error": "ALREADY_OWNED"}); return True
            blocked = _blocked_by_protection(c, uid)
            if blocked: handler.send_json(409, {"error": blocked}); return True
            now = _now(); cur = _wallet_balance(c, uid); price = int(item["price"])
            if cur < price: handler.send_json(409, {"error": "INSUFFICIENT_FUNDS"}); return True
            after = cur - price; c.execute("BEGIN IMMEDIATE")
            c.execute("UPDATE users SET balance=?,last_active=? WHERE id=?", (after, now, uid))
            c.execute("INSERT INTO shop_ownership VALUES(?,?,?,?)", (uid, iid, 0, now))
            c.execute("INSERT INTO wallet_ledger(user_id,type,amount,balance_after,reference,created_at,idempotency_key) VALUES(?,?,?,?,?,?,?)", (uid, "SHOP", -price, after, "shop:" + iid, now, key or secrets.token_hex(12)))
            response = {"ok": True, "itemId": iid, "balance": after, "replayed": False}; _save_idempotent(c, uid, key, response); c.commit(); _audit(handler, u, "SHOP_PURCHASE", iid)
            handler.send_json(200, response); return True

        if p == "/v1/shop/equip":
            iid = str(q.get("itemId", "")).strip(); equipped = bool(q.get("equipped", False))
            if not c.execute("SELECT 1 FROM shop_ownership WHERE user_id=? AND item_id=?", (uid, iid)).fetchone(): handler.send_json(404, {"error": "ITEM_NOT_OWNED"}); return True
            if equipped: c.execute("UPDATE shop_ownership SET equipped=0 WHERE user_id=?", (uid,))
            c.execute("UPDATE shop_ownership SET equipped=? WHERE user_id=? AND item_id=?", (1 if equipped else 0, uid, iid)); c.commit(); _audit(handler, u, "SHOP_EQUIP", iid)
            handler.send_json(200, {"ok": True, "itemId": iid, "equipped": equipped}); return True

        if p in ("/v1/social/follow", "/v1/social/unfollow"):
            try: target = int(q.get("userId"))
            except Exception: target = 0
            if target <= 0 or not c.execute("SELECT 1 FROM users WHERE id=? AND status='ACTIVE'", (target,)).fetchone(): handler.send_json(404, {"error": "USER_NOT_FOUND"}); return True
            if target == uid: handler.send_json(409, {"error": "CANNOT_FOLLOW_SELF"}); return True
            is_follow = p == "/v1/social/follow"
            if is_follow:
                c.execute("INSERT OR IGNORE INTO social_follows(user_id,target_user_id,created_at) VALUES(?,?,?)", (uid, target, _now()))
            else:
                c.execute("DELETE FROM social_follows WHERE user_id=? AND target_user_id=?", (uid, target))
            c.commit(); _audit(handler, u, "SOCIAL_FOLLOW" if is_follow else "SOCIAL_UNFOLLOW", str(target)); handler.send_json(200, {"ok": True, "userId": target, "following": is_follow}); return True

        if p == "/v1/staking/stake":
            try: amount = int(q.get("amount"));
            except Exception: amount = 0
            key = str(q.get("idempotencyKey", "")).strip()
            if amount <= 0: handler.send_json(400, {"error": "INVALID_AMOUNT"}); return True
            replay = _idempotent(uid, key)
            if replay is not None: replay["replayed"] = True; handler.send_json(200, replay); return True
            blocked = _blocked_by_protection(c, uid)
            if blocked: handler.send_json(409, {"error": blocked}); return True
            cur = _wallet_balance(c, uid)
            if cur < amount: handler.send_json(409, {"error": "INSUFFICIENT_FUNDS"}); return True
            now = _now(); pid = secrets.token_hex(12); after = cur - amount; c.execute("BEGIN IMMEDIATE")
            c.execute("UPDATE users SET balance=?,last_active=? WHERE id=?", (after, now, uid))
            c.execute("INSERT INTO staking_positions VALUES(?,?,?,?,?,?)", (pid, uid, amount, "ACTIVE", now, 0))
            c.execute("INSERT INTO wallet_ledger(user_id,type,amount,balance_after,reference,created_at,idempotency_key) VALUES(?,?,?,?,?,?,?)", (uid, "STAKE", -amount, after, "stake:" + pid, now, key or "stake:" + pid))
            response = {"ok": True, "positionId": pid, "amount": amount, "balance": after, "replayed": False}; _save_idempotent(c, uid, key, response); c.commit(); _audit(handler, u, "STAKE", pid); handler.send_json(200, response); return True

        if p == "/v1/staking/unstake":
            pid = str(q.get("positionId", "")).strip(); row = c.execute("SELECT * FROM staking_positions WHERE id=? AND user_id=?", (pid, uid)).fetchone()
            if not row: handler.send_json(404, {"error": "POSITION_NOT_FOUND"}); return True
            if row["status"] != "ACTIVE": handler.send_json(409, {"error": "POSITION_NOT_ACTIVE"}); return True
            now = _now(); after = _wallet_balance(c, uid) + int(row["amount"]); c.execute("BEGIN IMMEDIATE"); c.execute("UPDATE users SET balance=?,last_active=? WHERE id=?", (after, now, uid)); c.execute("UPDATE staking_positions SET status='UNSTAKED',unstaked_at=? WHERE id=?", (now, pid)); c.execute("INSERT INTO wallet_ledger(user_id,type,amount,balance_after,reference,created_at,idempotency_key) VALUES(?,?,?,?,?,?,?)", (uid, "UNSTAKE", int(row["amount"]), after, "unstake:" + pid, now, "unstake:" + pid)); c.commit(); _audit(handler, u, "UNSTAKE", pid); handler.send_json(200, {"ok": True, "positionId": pid, "amount": int(row["amount"]), "balance": after}); return True

        if p == "/v1/support/tickets":
            subject = str(q.get("subject", "")).strip(); body = str(q.get("body", "")).strip()
            if not subject or not body: handler.send_json(400, {"error": "INVALID_TICKET"}); return True
            open_count = c.execute("SELECT COUNT(*) n FROM support_tickets WHERE user_id=? AND status='OPEN'", (uid,)).fetchone()["n"]
            if open_count >= 10: handler.send_json(409, {"error": "TOO_MANY_OPEN_TICKETS"}); return True
            now = _now(); tid = secrets.token_hex(10); c.execute("INSERT INTO support_tickets VALUES(?,?,?,?,?,?,?)", (tid, uid, subject[:160], body[:10000], "OPEN", now, now)); c.commit(); _audit(handler, u, "SUPPORT_TICKET_CREATE", tid); handler.send_json(201, {"ok": True, "id": tid, "status": "OPEN"}); return True

        if p == "/v1/protection":
            try: hours = int(q.get("selfExcludeHours", 0))
            except Exception: hours = 0
            if hours <= 0: handler.send_json(400, {"error": "INVALID_SELF_EXCLUSION"}); return True
            until = _now() + hours * 3600; c.execute("INSERT INTO protection_settings(user_id,self_excluded_until,daily_deposit_limit,updated_at) VALUES(?,?,0,?) ON CONFLICT(user_id) DO UPDATE SET self_excluded_until=excluded.self_excluded_until,updated_at=excluded.updated_at", (uid, until, _now())); c.commit(); _audit(handler, u, "SELF_EXCLUDE", str(hours)); handler.send_json(200, {"ok": True, "selfExcluded": True, "selfExcludedUntil": until}); return True

        if p == "/v1/backup":
            settings = _user_settings(c, uid)
            follows = [r["target_user_id"] for r in c.execute("SELECT target_user_id FROM social_follows WHERE user_id=?", (uid,)).fetchall()]
            equipped = [r["item_id"] for r in c.execute("SELECT item_id FROM shop_ownership WHERE user_id=? AND equipped=1", (uid,)).fetchall()]
            payload = {"version": 1, "settings": settings, "follows": follows, "equipped": equipped}
            raw = _json(payload); checksum = hashlib.sha256(raw.encode()).hexdigest(); bid = secrets.token_hex(12); now = _now(); c.execute("INSERT INTO server_backups VALUES(?,?,?,?,?)", (bid, uid, now, checksum, raw))
            c.execute("DELETE FROM server_backups WHERE user_id=? AND id NOT IN (SELECT id FROM server_backups WHERE user_id=? ORDER BY created_at DESC LIMIT 10)", (uid, uid)); c.commit(); _audit(handler, u, "ACCOUNT_BACKUP_CREATE", bid); handler.send_json(201, {"ok": True, "id": bid, "createdAt": now, "checksum": checksum}); return True

        if p == "/v1/backup/restore":
            bid = str(q.get("backupId", "")).strip(); row = c.execute("SELECT * FROM server_backups WHERE id=? AND user_id=?", (bid, uid)).fetchone()
            if not row: handler.send_json(404, {"error": "BACKUP_NOT_FOUND"}); return True
            if hashlib.sha256(row["payload"].encode()).hexdigest() != row["checksum"]: handler.send_json(409, {"error": "BACKUP_CORRUPT"}); return True
            try: payload = json.loads(row["payload"])
            except Exception: handler.send_json(409, {"error": "BACKUP_CORRUPT"}); return True
            c.execute("INSERT INTO user_settings(user_id,settings,updated_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET settings=excluded.settings,updated_at=excluded.updated_at", (uid, _json(payload.get("settings", {})), _now()))
            c.execute("UPDATE shop_ownership SET equipped=0 WHERE user_id=?", (uid,))
            for iid in payload.get("equipped", []): c.execute("UPDATE shop_ownership SET equipped=1 WHERE user_id=? AND item_id=?", (uid, str(iid)))
            c.execute("DELETE FROM social_follows WHERE user_id=?", (uid,))
            for target in payload.get("follows", []):
                try: c.execute("INSERT OR IGNORE INTO social_follows(user_id,target_user_id,created_at) VALUES(?,?,?)", (uid, int(target), _now()))
                except Exception: pass
            c.commit(); _audit(handler, u, "ACCOUNT_BACKUP_RESTORE", bid); handler.send_json(200, {"ok": True, "backupId": bid}); return True

        if p == "/v1/chat":
            message = str(q.get("message", "")).strip()
            if not message: handler.send_json(400, {"error": "INVALID_MESSAGE"}); return True
            if len(message) > 2000: handler.send_json(413, {"error": "MESSAGE_TOO_LONG"}); return True
            now = _now(); c.execute("INSERT INTO chat_messages(user_id,username,message,mine,created_at) VALUES(?,?,?,?,?)", (uid, u["username"], message, 1, now)); c.commit(); _audit(handler, u, "CHAT_MESSAGE", "user chat")
            handler.send_json(200, {"ok": True, "message": message, "created_at": now}); return True

        if p == "/v1/ai":
            message = str(q.get("message", "")).strip()
            if not message: handler.send_json(400, {"error": "INVALID_MESSAGE"}); return True
            # No fake external AI claim: this is a server-side assistant endpoint.
            # A real provider can be added later through api_provider_config.
            handler.send_json(200, {"ok": True, "reply": "Your request was received by the BetSimulator server. AI provider is not configured on this backend yet."}); return True

        return False
    finally:
        c.close()


def _handle_put(handler, p: str, q: Dict[str, Any]):
    if p != "/v1/settings":
        return False
    u = _require(handler)
    if not u:
        return True
    c = db(); uid = int(u["id"])
    try:
        if p == "/v1/settings":
            settings = q.get("settings") if isinstance(q.get("settings"), dict) else {}
            now = _now(); c.execute("INSERT INTO user_settings(user_id,settings,updated_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET settings=excluded.settings,updated_at=excluded.updated_at", (uid, _json(settings), now)); c.commit(); c.close(); c = None; _audit(handler, u, "SETTINGS_UPDATE"); handler.send_json(200, {"ok": True, "settings": settings}); return True
        return False
    finally:
        if c is not None:
            c.close()


def handle(handler, method: str, path: str, query_or_body) -> bool:
    """Return True when the route was consumed."""
    # server.py calls us before its own routes. We only own non-game feature routes.
    if method == "GET":
        return _handle_get(handler, path)
    if method == "POST":
        return _handle_post(handler, path, query_or_body if isinstance(query_or_body, dict) else {})
    if method == "PUT":
        return _handle_put(handler, path, query_or_body if isinstance(query_or_body, dict) else {})
    return False
