# BetSimulator Phase 8 Termux Backup Server

Install:
bash scripts/install.sh

Start:
bash scripts/start.sh

Stop:
bash scripts/stop.sh

Watchdog:
bash scripts/watchdog.sh

Port:
8787

Role:
BACKUP


## Startup fix
The start script now creates `logs/` and `data/` automatically before launching.

## Local endpoint
The backup server is HTTP on port 8787:
`http://127.0.0.1:8787/`

Important: this server does **not** provide HTTPS by itself. If the Android client/control center is configured to reject HTTP, the client configuration must allow localhost HTTP for development, or an HTTPS reverse proxy/certificate must be placed in front of this server. Do not enter `https://127.0.0.1:8787` unless TLS is actually configured.

## Verify
```bash
cd ~/BetSimulatorServer/Termux_Backup_Server_BetSimulator_PHASE8
bash scripts/start.sh
curl -i http://127.0.0.1:8787/v1/system/health
```
Expected: HTTP 200 and `"ok": true`.
