# BetSimulator — Render Complete Deploy Package

This package preserves the original server source. No original source file is deleted.

## What is ready

- Python backend Web Service
- Render Blueprint (`render.yaml`)
- Render start script
- `0.0.0.0` binding
- Render `$PORT` support
- Health check: `/v1/system/health`
- HTTPS is provided by Render at the public `onrender.com` URL
- Python standard-library backend; `requirements.txt` needs no third-party package

## Deploy

1. Push this directory to a GitHub repository.
2. In Render choose **New + → Blueprint** and select the repository.
3. Render reads `render.yaml`.
4. Wait for the Web Service to become Live.
5. Open:

`https://<your-service>.onrender.com/v1/system/health`

Expected response:

`{"ok": true, "service": "betsimulator-api", "version": "3.0", ...}`

## APK / Control Center

Do NOT use `127.0.0.1`, `localhost`, or `http://` after deployment.

Use:

`https://<your-service>.onrender.com/`

as the backend base URL.

## Important database limitation

The current backend uses SQLite. Render Free Web Services have ephemeral local storage, so SQLite data on the instance must not be considered permanent production storage.

Therefore this package is **fully ready to deploy and validate the API**, but a permanent user/wallet/transaction database still requires an external persistent database or a paid persistent disk.

Do not put real-money/payment production data into the ephemeral SQLite instance.

## Security

Set any production secrets through Render Environment Variables rather than committing secrets to Git.

## Games

The server package does not force the Games area online. The Android client can keep Games offline as requested.

## Local verification

Run:

`python3 -m py_compile server.py online_features.py config.py`

Then:

`BETSIM_HOST=127.0.0.1 BETSIM_PORT=8787 python3 server.py`

and:

`curl http://127.0.0.1:8787/v1/system/health`


## Persistence status

This Render Free package is ready for an online smoke test. The current SQLite database is not persistent on Render Free. See `FREE_ONLINE_ARCHITECTURE.md` for the Phase 2 PostgreSQL migration.
