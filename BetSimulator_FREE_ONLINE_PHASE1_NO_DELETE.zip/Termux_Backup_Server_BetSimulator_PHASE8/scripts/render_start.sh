#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export BETSIM_HOST="${BETSIM_HOST:-0.0.0.0}"
export BETSIM_PORT="${PORT:-${BETSIM_PORT:-8787}}"
exec python3 server.py
