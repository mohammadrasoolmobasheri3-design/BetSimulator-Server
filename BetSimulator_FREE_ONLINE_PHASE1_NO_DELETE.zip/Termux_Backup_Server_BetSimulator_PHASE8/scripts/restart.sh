#!/data/data/com.termux/files/usr/bin/bash
./stop.sh
./start.sh
