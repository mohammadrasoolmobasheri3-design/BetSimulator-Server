#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")/.."
while true; do
 if ! pgrep -f "python server.py" >/dev/null; then
   ./scripts/start.sh
 fi
 sleep 30
done
