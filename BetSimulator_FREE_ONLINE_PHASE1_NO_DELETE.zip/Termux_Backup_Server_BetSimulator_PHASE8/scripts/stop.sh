#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")/.."
if [ -f server.pid ]; then
 kill $(cat server.pid)
 rm server.pid
fi
