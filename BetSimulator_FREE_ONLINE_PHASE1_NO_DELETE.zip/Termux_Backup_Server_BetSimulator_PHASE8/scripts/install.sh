#!/data/data/com.termux/files/usr/bin/bash
pkg update -y
pkg install python tmux -y
termux-wake-lock
echo "Install complete"
