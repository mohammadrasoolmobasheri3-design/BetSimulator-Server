#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")/.."
mkdir -p logs data
termux-wake-lock
nohup python server.py > logs/backup.log 2>&1 &
echo $! > server.pid
echo "Backup server started"
