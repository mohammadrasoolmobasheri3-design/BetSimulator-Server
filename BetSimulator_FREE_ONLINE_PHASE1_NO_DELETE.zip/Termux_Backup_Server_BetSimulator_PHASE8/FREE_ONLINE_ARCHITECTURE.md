# BetSimulator — Free Online Architecture

## Phase 1: zero-cost public API

- Runtime: Render Free Web Service
- Transport: HTTPS provided by Render
- Health: `/v1/system/health`
- Bind: `0.0.0.0`
- Port: Render's `$PORT`
- Backend: existing Python `server.py` + `online_features.py`
- Game area: remains controlled by the existing app logic

## Important persistence limitation

The current backend uses SQLite (`data/betsimulator.db`). Render Free Web Services have an
ephemeral filesystem: local SQLite files are lost on restart, redeploy, or spin-down.

Therefore this package is **online-deployable**, but it is NOT claimed to be a permanent
production database until the SQLite layer is migrated to an external PostgreSQL-compatible
database.

Do not put real money, payment credentials, or irreplaceable user data into this Phase 1
deployment.

## Phase 2: persistent free database

The intended next migration target is a free PostgreSQL provider (for example Supabase or
Neon). The existing API contract should remain stable while the repository layer is migrated.
No Android UI rewrite should be required if the API contract is preserved.

## Render start

Render supplies `PORT`. `scripts/render_start.sh` maps it to `BETSIM_PORT` and starts
`server.py`.

## Health check

`GET /v1/system/health` must return HTTP 200.
