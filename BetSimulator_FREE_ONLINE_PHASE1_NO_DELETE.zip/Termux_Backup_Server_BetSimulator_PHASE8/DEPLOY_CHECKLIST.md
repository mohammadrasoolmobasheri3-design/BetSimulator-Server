# Render deployment checklist

- [ ] Repository contains this folder contents at its root
- [ ] `render.yaml` is present
- [ ] Render detects the Blueprint
- [ ] Build succeeds
- [ ] Service becomes Live
- [ ] `/v1/system/health` returns HTTP 200
- [ ] Public HTTPS URL copied
- [ ] APK backend URL changed to public HTTPS URL
- [ ] Control Center backend URL changed to the same public HTTPS URL
- [ ] Login tested
- [ ] Wallet/profile/tournament/notification endpoints tested
- [ ] SQLite is NOT treated as permanent production storage
