# Deploy Now

1. Put this folder in a GitHub repository.
2. In Render choose **New -> Blueprint** and select the repository.
3. Render reads `render.yaml`.
4. Use the **Free** Web Service plan.
5. After deploy, open:

   `https://YOUR-SERVICE.onrender.com/v1/system/health`

6. Expect HTTP 200 and JSON containing:
   `{"ok": true, "service": "betsimulator-api", ...}`

7. Use the public HTTPS service URL as the Backend URL for the Android app and Control Center.

## Do not use the Render Free filesystem as permanent storage

The current backend is SQLite. It is suitable for the first online smoke test only.
