SERVER_ROLE="BACKUP"
SERVER_NAME="Termux-Backup-01"
HOST="0.0.0.0"
PORT=8787
DATABASE="data/betsimulator.db"
