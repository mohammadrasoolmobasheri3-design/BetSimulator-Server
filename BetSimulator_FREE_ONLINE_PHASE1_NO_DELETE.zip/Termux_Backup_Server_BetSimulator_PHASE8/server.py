#!/usr/bin/env python3
import base64, hashlib, hmac, json, os, secrets, sqlite3, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
import online_features

HOST=os.environ.get('BETSIM_HOST','0.0.0.0'); PORT=int(os.environ.get('BETSIM_PORT','8787'))
ROOT=os.path.dirname(__file__); DATA=os.path.join(ROOT,'data'); DB_PATH=os.environ.get('BETSIM_DB',os.path.join(DATA,'betsimulator.db'))
TOKEN_TTL=7*24*3600; PBKDF2_ITERS=210_000; os.makedirs(DATA,exist_ok=True)
SECRET_PATH=os.path.join(DATA,'server.secret')
if not os.path.exists(SECRET_PATH): open(SECRET_PATH,'wb').write(secrets.token_bytes(32))
SECRET=open(SECRET_PATH,'rb').read()
ADMIN_PERMISSIONS={'VIEW_USERS','MANAGE_USERS','VIEW_WALLET','MANAGE_WALLET','VIEW_GAMES','MANAGE_GAMES','VIEW_TOURNAMENTS','MANAGE_TOURNAMENTS','VIEW_REWARDS','MANAGE_REWARDS','VIEW_VIP','MANAGE_VIP','VIEW_ANALYTICS','VIEW_HISTORY','MANAGE_NOTIFICATIONS','MANAGE_SECURITY','MANAGE_PLAYER_PROTECTION','MANAGE_SYSTEM'}

def db():
 c=sqlite3.connect(DB_PATH,timeout=15); c.row_factory=sqlite3.Row; c.execute('PRAGMA journal_mode=WAL'); c.execute('PRAGMA foreign_keys=ON'); return c

def init():
 c=db(); c.executescript('''
 CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'ACTIVE',balance INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL,last_active INTEGER NOT NULL,role TEXT NOT NULL DEFAULT 'USER');
 CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL,expires_at INTEGER NOT NULL,created_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,actor_user_id INTEGER,action TEXT NOT NULL,detail TEXT,created_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS api_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,path TEXT NOT NULL,method TEXT NOT NULL,status INTEGER NOT NULL,created_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS wallet_ledger(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,type TEXT NOT NULL,amount INTEGER NOT NULL,balance_after INTEGER NOT NULL,reference TEXT,created_at INTEGER NOT NULL,idempotency_key TEXT UNIQUE);
 CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,title TEXT NOT NULL,body TEXT NOT NULL,read_at INTEGER,created_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS games(id TEXT PRIMARY KEY,name TEXT NOT NULL,category TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 1);
 CREATE TABLE IF NOT EXISTS tournaments(id TEXT PRIMARY KEY,title TEXT NOT NULL,state TEXT NOT NULL,prize_pool INTEGER NOT NULL,entry_fee INTEGER NOT NULL,players INTEGER NOT NULL,max_players INTEGER NOT NULL,starts_at INTEGER NOT NULL,ends_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS leaderboard(tournament_id TEXT NOT NULL,user_id INTEGER NOT NULL,score INTEGER NOT NULL,prize INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(tournament_id,user_id));
 CREATE TABLE IF NOT EXISTS tournament_members(tournament_id TEXT NOT NULL,user_id INTEGER NOT NULL,joined_at INTEGER NOT NULL,PRIMARY KEY(tournament_id,user_id));
 CREATE TABLE IF NOT EXISTS idempotency(user_id INTEGER NOT NULL,key TEXT NOT NULL,response TEXT NOT NULL,created_at INTEGER NOT NULL,PRIMARY KEY(user_id,key));
 CREATE TABLE IF NOT EXISTS rewards(user_id INTEGER PRIMARY KEY,points INTEGER NOT NULL DEFAULT 0,vip_level INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS shop_items(id TEXT PRIMARY KEY,name TEXT NOT NULL,price INTEGER NOT NULL,enabled INTEGER NOT NULL DEFAULT 1);
 CREATE TABLE IF NOT EXISTS social_follows(user_id INTEGER NOT NULL,target_user_id INTEGER NOT NULL,created_at INTEGER NOT NULL,PRIMARY KEY(user_id,target_user_id));
 CREATE TABLE IF NOT EXISTS game_rounds(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,game_id TEXT NOT NULL,round_id TEXT NOT NULL,stake INTEGER NOT NULL,payout INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL,created_at INTEGER NOT NULL,settled_at INTEGER NOT NULL DEFAULT 0,UNIQUE(user_id,game_id,round_id));
 CREATE TABLE IF NOT EXISTS game_events(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,game_id TEXT NOT NULL,action TEXT NOT NULL,payload TEXT NOT NULL,created_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS user_groups(id TEXT PRIMARY KEY,name TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'ACTIVE',created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS group_permissions(group_id TEXT NOT NULL,permission TEXT NOT NULL,PRIMARY KEY(group_id,permission));
 CREATE TABLE IF NOT EXISTS group_members(group_id TEXT NOT NULL,user_id INTEGER NOT NULL,PRIMARY KEY(group_id,user_id));
 CREATE INDEX IF NOT EXISTS idx_game_rounds_user ON game_rounds(user_id,created_at);
 CREATE INDEX IF NOT EXISTS idx_api_logs_created ON api_logs(created_at);
 ''')
 # Safe migration for DBs created by older builds.
 cols={r['name'] for r in c.execute('PRAGMA table_info(users)').fetchall()}
 if 'role' not in cols: c.execute("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'USER'")
 games=[('crash-royal','Crash Royal','CRASH'),('crash','Crash','CRASH'),('baccarat','Baccarat','CASINO'),('blackjack','Blackjack','CASINO'),('roulette','Roulette','CASINO'),('casino','Casino','CASINO'),('pop','Pop','ARCADE'),('football','Football','SPORT'),('basketball','Basketball','SPORT'),('tennis','Tennis','SPORT')]
 for g in games: c.execute('INSERT OR IGNORE INTO games(id,name,category,enabled) VALUES(?,?,?,1)',g)
 now=int(time.time()); ts=[('t1','Neon Championship','LIVE',25000,100,0,500,now-3600,now+7200),('t2','Golden Rush','UPCOMING',50000,250,0,500,now+7200,now+14400),('t3','Weekend Masters','FINISHED',10000,50,0,500,now-172800,now-86400)]
 for t in ts: c.execute('INSERT OR IGNORE INTO tournaments(id,title,state,prize_pool,entry_fee,players,max_players,starts_at,ends_at) VALUES(?,?,?,?,?,?,?,?,?)',t)
 for it in [('vip-pass','VIP Pass',1000),('theme-neon','Neon Theme',250)]: c.execute('INSERT OR IGNORE INTO shop_items(id,name,price,enabled) VALUES(?,?,?,1)',it)
 c.commit(); c.close()
 online_features.init_schema(db)

def hp(p,s=None):
 s=s or secrets.token_bytes(16); d=hashlib.pbkdf2_hmac('sha256',p.encode(),s,PBKDF2_ITERS); return 'pbkdf2$%d$%s$%s'%(PBKDF2_ITERS,base64.urlsafe_b64encode(s).decode().rstrip('='),base64.urlsafe_b64encode(d).decode().rstrip('='))
def vp(p,stored):
 try:
  _,it,ss,sh=stored.split('$',3); s=base64.urlsafe_b64decode(ss+'==='); expected=base64.urlsafe_b64decode(sh+'==='); actual=hashlib.pbkdf2_hmac('sha256',p.encode(),s,int(it)); return hmac.compare_digest(actual,expected)
 except Exception:return False
def th(t): return hashlib.sha256(t.encode()).hexdigest()
def issue(uid):
 raw=secrets.token_urlsafe(48); now=int(time.time()); c=db(); c.execute('INSERT INTO sessions VALUES(?,?,?,?)',(th(raw),uid,now+TOKEN_TTL,now)); c.commit(); c.close(); return raw

def get_user(h):
 a=h.headers.get('Authorization','')
 if not a.startswith('Bearer '): return None
 c=db(); r=c.execute('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.status="ACTIVE"',(th(a[7:].strip()),int(time.time()))).fetchone()
 if r: c.execute('UPDATE users SET last_active=? WHERE id=?',(int(time.time()),r['id'])); c.commit()
 c.close(); return r

def permissions_for(c,u):
 if u['role']=='SUPER_ADMIN': return sorted(ADMIN_PERMISSIONS)
 rows=c.execute('SELECT gp.permission FROM group_permissions gp JOIN group_members gm ON gm.group_id=gp.group_id WHERE gm.user_id=?',(u['id'],)).fetchall()
 return sorted({r['permission'] for r in rows})

class API(BaseHTTPRequestHandler):
 server_version='BetSimulatorBackend/3.0'
 def log_message(self,*a): pass
 def send_json(self,code,p):
  b=json.dumps(p,ensure_ascii=False).encode(); self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(b)
  try:
   u=get_user(self); uid=u['id'] if u else None; c=db(); c.execute('INSERT INTO api_logs(user_id,path,method,status,created_at) VALUES(?,?,?,?,?)',(uid,urlparse(self.path).path,self.command,code,int(time.time()))); c.commit(); c.close()
  except Exception: pass
 def body(self):
  n=int(self.headers.get('Content-Length','0')); return json.loads(self.rfile.read(n).decode() or '{}')
 def audit(self,u,a,d=''):
  c=db(); c.execute('INSERT INTO audit_log(actor_user_id,action,detail,created_at) VALUES(?,?,?,?)',(u['id'] if u else None,a,d,int(time.time()))); c.commit(); c.close()
 def require(self):
  u=get_user(self)
  if not u:self.send_json(401,{'error':'UNAUTHORIZED'})
  return u
 def require_admin(self,perm=None):
  u=self.require()
  if not u:return None
  c=db(); allowed=u['role']=='SUPER_ADMIN' or (perm is not None and perm in permissions_for(c,u)); c.close()
  if not allowed:self.send_json(403,{'error':'FORBIDDEN','requiredPermission':perm}); return None
  return u
 def do_GET(self):
  p=urlparse(self.path).path; q=parse_qs(urlparse(self.path).query)
  if online_features.handle(self,'GET',p,q): return
  if p=='/v1/system/health': self.send_json(200,{'ok':True,'service':'betsimulator-api','version':'3.0','time':int(time.time())}); return
  if p=='/v1/me':
   u=self.require();
   if u:self.send_json(200,{'user':dict(id=u['id'],username=u['username'],status=u['status'],balance=u['balance'],createdAt=u['created_at'],lastActive=u['last_active'])})
   return
  if p in ['/v1/wallet','/v1/wallet/transactions']:
   u=self.require();
   if not u:return
   c=db()
   if p.endswith('wallet'): self.send_json(200,{'balance':u['balance'],'locked':0,'pending':0,'currency':'USD'}); c.close(); return
   rows=c.execute('SELECT id,type,amount,balance_after,reference,created_at FROM wallet_ledger WHERE user_id=? ORDER BY id DESC LIMIT 200',(u['id'],)).fetchall(); c.close(); self.send_json(200,{'transactions':[dict(r) for r in rows]}); return
  if p=='/v1/games':
   u=self.require();
   if not u:return
   c=db(); rows=c.execute('SELECT id,name,category,enabled FROM games ORDER BY name').fetchall(); c.close(); self.send_json(200,{'games':[dict(r,enabled=bool(r['enabled'])) for r in rows]}); return
  if p=='/v1/tournaments':
   u=self.require();
   if not u:return
   c=db(); rows=c.execute('''SELECT t.id,t.title,t.state,t.prize_pool,t.entry_fee,t.players,t.max_players,t.starts_at,t.ends_at,CASE WHEN m.user_id IS NULL THEN 0 ELSE 1 END AS joined FROM tournaments t LEFT JOIN tournament_members m ON m.tournament_id=t.id AND m.user_id=? ORDER BY t.starts_at''',(u['id'],)).fetchall(); c.close(); self.send_json(200,{'tournaments':[dict(r,prizePool=r['prize_pool'],entryFee=r['entry_fee'],maxPlayers=r['max_players'],startsAt=r['starts_at'],endsAt=r['ends_at'],joined=bool(r['joined'])) for r in rows]}); return
  if p.startswith('/v1/tournaments/') and p.endswith('/leaderboard'):
   u=self.require();
   if not u:return
   tid=p.split('/')[3]; c=db(); rows=c.execute('SELECT l.score,l.prize,u.username FROM leaderboard l JOIN users u ON u.id=l.user_id WHERE l.tournament_id=? ORDER BY l.score DESC,l.user_id LIMIT 100',(tid,)).fetchall(); c.close(); self.send_json(200,{'tournamentId':tid,'entries':[{'rank':i+1,'username':r['username'],'score':r['score'],'prize':r['prize']} for i,r in enumerate(rows)]}); return
  if p=='/v1/notifications':
   u=self.require();
   if not u:return
   c=db(); rows=c.execute('SELECT id,title,body,read_at,created_at FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 100',(u['id'],)).fetchall(); c.close(); self.send_json(200,{'notifications':[dict(r) for r in rows]}); return
  if p.startswith('/v1/games/') and p.endswith('/events'):
   u=self.require()
   if not u:return
   gid=p.split('/')[3];c=db();rows=c.execute('SELECT id,game_id,action,payload,created_at FROM game_events WHERE user_id=? AND game_id=? ORDER BY created_at DESC LIMIT 100',(u['id'],gid)).fetchall();c.close();self.send_json(200,{'events':[{'id':r['id'],'gameId':r['game_id'],'action':r['action'],'payload':json.loads(r['payload']),'createdAt':r['created_at']} for r in rows]});return
  # Control Center admin API
  if p=='/v1/admin/dashboard':
   u=self.require_admin('VIEW_ANALYTICS');
   if not u:return
   c=db(); out={'users':c.execute('SELECT COUNT(*) n FROM users').fetchone()['n'],'activeUsers':c.execute("SELECT COUNT(*) n FROM users WHERE status='ACTIVE'").fetchone()['n'],'totalBalance':c.execute('SELECT COALESCE(SUM(balance),0) n FROM users').fetchone()['n'],'games':c.execute('SELECT COUNT(*) n FROM games WHERE enabled=1').fetchone()['n'],'tournaments':c.execute("SELECT COUNT(*) n FROM tournaments WHERE state!='FINISHED'").fetchone()['n']}; c.close(); self.send_json(200,out); return
  if p.startswith('/v1/admin/tables/') and p.endswith('/count'):
   u=self.require_admin('VIEW_ANALYTICS');
   if not u:return
   table=p.split('/')[3]; allowed={'users','games','tournaments','wallet_ledger','audit_log','notifications','game_rounds','game_events','user_groups'}
   if table not in allowed:self.send_json(400,{'error':'TABLE_NOT_ALLOWED'});return
   c=db(); n=c.execute('SELECT COUNT(*) n FROM '+table).fetchone()['n']; c.close(); self.send_json(200,{'table':table,'count':n}); return
  if p=='/v1/admin/audit':
   u=self.require_admin('VIEW_HISTORY');
   if not u:return
   limit=min(max(int(q.get('limit',['50'])[0]),1),200); c=db(); rows=c.execute('SELECT a.id,a.actor_user_id,a.action,a.detail,a.created_at,u.username FROM audit_log a LEFT JOIN users u ON u.id=a.actor_user_id ORDER BY a.id DESC LIMIT ?',(limit,)).fetchall(); c.close(); self.send_json(200,{'items':[dict(r) for r in rows]}); return
  if p=='/v1/admin/api-logs':
   u=self.require_admin('VIEW_HISTORY');
   if not u:return
   limit=min(max(int(q.get('limit',['50'])[0]),1),200); c=db(); rows=c.execute('SELECT * FROM api_logs ORDER BY id DESC LIMIT ?',(limit,)).fetchall(); c.close(); self.send_json(200,{'items':[dict(r) for r in rows]}); return
  if p=='/v1/admin/users':
   u=self.require_admin('VIEW_USERS');
   if not u:return
   limit=min(max(int(q.get('limit',['500'])[0]),1),1000); c=db(); rows=c.execute('SELECT id,username,status,balance,created_at,last_active,role FROM users ORDER BY id DESC LIMIT ?',(limit,)).fetchall(); c.close(); self.send_json(200,{'items':[dict(r) for r in rows]}); return
  if p=='/v1/admin/user-groups':
   u=self.require_admin('VIEW_USERS');
   if not u:return
   c=db(); rows=c.execute('SELECT g.*,COUNT(gm.user_id) memberCount FROM user_groups g LEFT JOIN group_members gm ON gm.group_id=g.id GROUP BY g.id ORDER BY g.name').fetchall(); out=[]
   for r in rows:
    perms=c.execute('SELECT permission FROM group_permissions WHERE group_id=? ORDER BY permission',(r['id'],)).fetchall(); out.append(dict(r,memberCount=r['memberCount'],permissions=[x['permission'] for x in perms]))
   c.close(); self.send_json(200,{'items':out}); return
  if p.startswith('/v1/admin/user-groups/') and p.endswith('/members'):
   u=self.require_admin('VIEW_USERS');
   if not u:return
   gid=p.split('/')[4]; c=db(); rows=c.execute('SELECT u.id,u.username FROM group_members gm JOIN users u ON u.id=gm.user_id WHERE gm.group_id=? ORDER BY u.username',(gid,)).fetchall(); c.close(); self.send_json(200,{'items':[r['id'] for r in rows],'users':[dict(r) for r in rows]}); return
  self.send_json(404,{'error':'NOT_FOUND'})
 def do_POST(self):
  p=urlparse(self.path).path
  try:q=self.body()
  except Exception:self.send_json(400,{'error':'INVALID_JSON'});return
  if online_features.handle(self,'POST',p,q): return
  if p=='/v1/auth/bootstrap':
   c=db(); count=c.execute("SELECT COUNT(*) n FROM users WHERE role!='USER'").fetchone()['n']
   if count>0:c.close();self.send_json(409,{'error':'BOOTSTRAP_ALREADY_COMPLETED'});return
   un=str(q.get('username','')).strip(); pw=str(q.get('password',''))
   if not 3<=len(un)<=64 or len(pw)<8:c.close();self.send_json(400,{'error':'INVALID_INPUT'});return
   now=int(time.time());
   try:cur=c.execute("INSERT INTO users(username,password_hash,status,balance,created_at,last_active,role) VALUES(?,?, 'ACTIVE',0,?,?, 'SUPER_ADMIN')",(un,hp(pw),now,now)); uid=cur.lastrowid; c.commit()
   except sqlite3.IntegrityError:c.close();self.send_json(409,{'error':'USERNAME_EXISTS'});return
   c.close(); token=issue(uid); self.send_json(201,{'token':token,'expiresIn':TOKEN_TTL,'username':un,'role':'SUPER_ADMIN','permissions':sorted(ADMIN_PERMISSIONS)});return
  if p=='/v1/auth/register':
   un=str(q.get('username','')).strip(); pw=str(q.get('password',''))
   if not 3<=len(un)<=64 or len(pw)<4:self.send_json(400,{'error':'INVALID_INPUT'});return
   now=int(time.time()); c=db()
   try:c.execute('INSERT INTO users(username,password_hash,created_at,last_active,role) VALUES(?,?,?,? ,"USER")',(un,hp(pw),now,now)); c.commit()
   except sqlite3.IntegrityError:c.close();self.send_json(409,{'error':'USERNAME_EXISTS'});return
   r=c.execute('SELECT id,username,status,balance FROM users WHERE username=?',(un,)).fetchone(); c.close(); self.send_json(201,{'user':dict(r)});return
  if p=='/v1/auth/login':
   un=str(q.get('username','')).strip(); pw=str(q.get('password','')); c=db(); u=c.execute('SELECT * FROM users WHERE username=?',(un,)).fetchone()
   if not u or u['status']!='ACTIVE' or not vp(pw,u['password_hash']):c.close();self.send_json(401,{'error':'INVALID_CREDENTIALS'});return
   t=issue(u['id']); perms=permissions_for(c,u); c.close(); self.audit(u,'USER_LOGIN'); self.send_json(200,{'token':t,'expiresIn':TOKEN_TTL,'username':u['username'],'role':u['role'],'permissions':perms,'user':{'id':u['id'],'username':u['username'],'status':u['status'],'balance':u['balance']}});return
  if p in ['/v1/wallet/deposit','/v1/wallet/withdraw']:
   u=self.require();
   if not u:return
   try:a=int(q.get('amount',0))
   except:a=0
   if a<=0:self.send_json(400,{'error':'INVALID_AMOUNT'});return
   key=str(q.get('idempotencyKey','')).strip() or secrets.token_urlsafe(18); typ='DEPOSIT' if p.endswith('deposit') else 'WITHDRAW'; delta=a if typ=='DEPOSIT' else -a
   c=db(); c.execute('BEGIN IMMEDIATE'); prior=c.execute('SELECT * FROM wallet_ledger WHERE idempotency_key=?',(key,)).fetchone()
   if prior:c.commit();c.close();self.send_json(200,{'balance':prior['balance_after'],'ledgerId':prior['id'],'replayed':True});return
   if typ=='DEPOSIT':
    blk=online_features.deposit_block(c,u['id'],a)
    if blk:c.rollback();c.close();self.send_json(blk[0],{'error':blk[1]});return
   current=c.execute('SELECT balance FROM users WHERE id=?',(u['id'],)).fetchone()['balance']
   if typ=='WITHDRAW' and current<a:c.rollback();c.close();self.send_json(409,{'error':'INSUFFICIENT_FUNDS'});return
   now=int(time.time()); after=current+delta; c.execute('UPDATE users SET balance=?,last_active=? WHERE id=?',(after,now,u['id'])); cur=c.execute('INSERT INTO wallet_ledger(user_id,type,amount,balance_after,reference,created_at,idempotency_key) VALUES(?,?,?,?,?,?,?)',(u['id'],typ,delta,after,str(q.get('reference','online')),now,key)); c.commit(); c.close(); self.audit(u,'WALLET_'+typ); self.send_json(200,{'balance':after,'ledgerId':cur.lastrowid,'replayed':False});return
  if p=='/v1/ai':
   u=self.require();
   if not u:return
   msg=str(q.get('message','')).strip();
   if not msg:self.send_json(400,{'error':'MESSAGE_REQUIRED'});return
   self.send_json(200,{'reply':'Your request was received by the BetSimulator server. A live support/AI service can process it when configured.'}); return
  if p=='/v1/auth/logout':
   u=self.require();
   if not u:return
   a=self.headers.get('Authorization','')[7:].strip(); c=db(); c.execute('DELETE FROM sessions WHERE token_hash=?',(th(a),)); c.commit(); c.close(); self.audit(u,'USER_LOGOUT'); self.send_json(200,{'ok':True}); return
  if p=='/v1/me/profile':
   u=self.require();
   if not u:return
   un=str(q.get('username','')).strip()
   if un:
    if not 3<=len(un)<=64:self.send_json(400,{'error':'INVALID_USERNAME'});return
    c=db()
    try:c.execute('UPDATE users SET username=? WHERE id=?',(un,u['id'])); c.commit()
    except sqlite3.IntegrityError:c.close();self.send_json(409,{'error':'USERNAME_EXISTS'});return
    c.close()
   self.send_json(200,{'ok':True}); return
  if p.startswith('/v1/notifications/') and p.endswith('/read'):
   u=self.require();
   if not u:return
   try:nid=int(p.split('/')[3])
   except:self.send_json(400,{'error':'INVALID_ID'});return
   c=db(); c.execute('UPDATE notifications SET read_at=? WHERE id=? AND user_id=?',(int(time.time()),nid,u['id'])); c.commit(); c.close(); self.send_json(200,{'ok':True}); return
  if p.startswith('/v1/tournaments/') and p.endswith('/join'):
   u=self.require();
   if not u:return
   tid=p.split('/')[3]; key=str(q.get('idempotencyKey','')).strip(); c=db(); c.execute('BEGIN IMMEDIATE'); t=c.execute('SELECT * FROM tournaments WHERE id=?',(tid,)).fetchone()
   if not t:c.rollback();c.close();self.send_json(404,{'error':'TOURNAMENT_NOT_FOUND'});return
   if t['state'] not in ('LIVE','UPCOMING'):c.rollback();c.close();self.send_json(409,{'error':'TOURNAMENT_CLOSED'});return
   if key:
    replay=c.execute('SELECT response FROM idempotency WHERE user_id=? AND key=?',(u['id'],key)).fetchone()
    if replay:c.commit();c.close();self.send_json(200,json.loads(replay['response']));return
   m=c.execute('SELECT 1 FROM tournament_members WHERE tournament_id=? AND user_id=?',(tid,u['id'])).fetchone()
   if m:c.commit();c.close();self.send_json(200,{'ok':True,'alreadyJoined':True});return
   if t['players']>=t['max_players']:c.rollback();c.close();self.send_json(409,{'error':'TOURNAMENT_FULL'});return
   blk=online_features.spend_block(c,u['id'])
   if blk:c.rollback();c.close();self.send_json(blk[0],{'error':blk[1]});return
   current=c.execute('SELECT balance FROM users WHERE id=?',(u['id'],)).fetchone()['balance']
   if current<t['entry_fee']:c.rollback();c.close();self.send_json(409,{'error':'INSUFFICIENT_FUNDS'});return
   now=int(time.time()); after=current-t['entry_fee']; response={'ok':True,'balance':after,'tournamentId':tid}; c.execute('UPDATE users SET balance=? WHERE id=?',(after,u['id'])); c.execute('INSERT INTO tournament_members VALUES(?,?,?)',(tid,u['id'],now)); c.execute('UPDATE tournaments SET players=players+1 WHERE id=?',(tid,)); c.execute('INSERT INTO wallet_ledger(user_id,type,amount,balance_after,reference,created_at,idempotency_key) VALUES(?,?,?,?,?,?,?)',(u['id'],'TOURNAMENT_ENTRY',-t['entry_fee'],after,tid,now,key or secrets.token_urlsafe(18))); 
   if key:c.execute('INSERT INTO idempotency(user_id,key,response,created_at) VALUES(?,?,?,?)',(u['id'],key,json.dumps(response),now))
   c.commit();c.close();self.audit(u,'TOURNAMENT_JOIN',tid);self.send_json(200,response);return
  if p.startswith('/v1/tournaments/') and p.endswith('/leave'):
   u=self.require();
   if not u:return
   tid=p.split('/')[3];c=db();m=c.execute('SELECT 1 FROM tournament_members WHERE tournament_id=? AND user_id=?',(tid,u['id'])).fetchone();
   if not m:c.close();self.send_json(404,{'error':'NOT_JOINED'});return
   t=c.execute('SELECT state,entry_fee FROM tournaments WHERE id=?',(tid,)).fetchone();
   if not t or t['state']=='FINISHED':c.close();self.send_json(409,{'error':'TOURNAMENT_CLOSED'});return
   # No automatic refund: leaving a live/upcoming tournament is an explicit business action.
   c.execute('DELETE FROM tournament_members WHERE tournament_id=? AND user_id=?',(tid,u['id']));c.execute('UPDATE tournaments SET players=MAX(players-1,0) WHERE id=?',(tid,));c.commit();c.close();self.send_json(200,{'ok':True});return
  if p.startswith('/v1/games/') and p.endswith('/rounds/open'):
   u=self.require();
   if not u:return
   gid=p.split('/')[3];rid=str(q.get('roundId','')).strip();key='round-open:'+gid+':'+rid
   try:stake=int(q.get('stake',0))
   except:stake=0
   if not rid or len(rid)>128 or stake<=0:self.send_json(400,{'error':'INVALID_ROUND'});return
   c=db();c.execute('BEGIN IMMEDIATE')
   try:
    g=c.execute('SELECT id,enabled FROM games WHERE id=?',(gid,)).fetchone()
    if not g:c.rollback();c.close();self.send_json(404,{'error':'GAME_NOT_FOUND'});return
    if not g['enabled']:c.rollback();c.close();self.send_json(409,{'error':'GAME_DISABLED'});return
    blk=online_features.spend_block(c,u['id'])
    if blk:c.rollback();c.close();self.send_json(blk[0],{'error':blk[1]});return
    existing=c.execute('SELECT * FROM game_rounds WHERE user_id=? AND game_id=? AND round_id=?',(u['id'],gid,rid)).fetchone()
    if existing:
     bal=c.execute('SELECT balance FROM users WHERE id=?',(u['id'],)).fetchone()['balance'];c.commit();c.close();self.send_json(200,{'ok':True,'roundId':rid,'gameId':gid,'stake':existing['stake'],'payout':existing['payout'],'status':existing['status'],'balance':bal,'replayed':True});return
    current=c.execute('SELECT balance FROM users WHERE id=?',(u['id'],)).fetchone()['balance']
    if current<stake:c.rollback();c.close();self.send_json(409,{'error':'INSUFFICIENT_FUNDS'});return
    now=int(time.time());after=current-stake;sid=secrets.token_urlsafe(18);c.execute('UPDATE users SET balance=?,last_active=? WHERE id=?',(after,now,u['id']));c.execute('INSERT INTO game_rounds(id,user_id,game_id,round_id,stake,payout,status,created_at) VALUES(?,?,?,?,0,0,?,?)',(sid,u['id'],gid,rid,'PENDING',now))
    # Fix inserted stake separately for clarity and compatibility.
    c.execute('UPDATE game_rounds SET stake=? WHERE id=?',(stake,sid));c.execute('INSERT INTO wallet_ledger(user_id,type,amount,balance_after,reference,created_at,idempotency_key) VALUES(?,?,?,?,?,?,?)',(u['id'],'BET',-stake,after,'bet:'+sid,now,key));c.commit();c.close();self.audit(u,'GAME_ROUND_OPEN',gid+':'+rid);self.send_json(200,{'ok':True,'roundId':rid,'gameId':gid,'stake':stake,'payout':0,'status':'PENDING','balance':after,'replayed':False});return
   except Exception:
    c.rollback();c.close();raise
  if p.startswith('/v1/games/') and p.endswith('/rounds/close'):
   u=self.require()
   if not u:return
   gid=p.split('/')[3]; rid=str(q.get('roundId','')).strip()
   try:payout=int(q.get('payout',0))
   except:payout=-1
   if not rid or payout<0:self.send_json(400,{'error':'INVALID_PAYOUT'});return
   c=db();c.execute('BEGIN IMMEDIATE')
   try:
    r=c.execute('SELECT * FROM game_rounds WHERE user_id=? AND game_id=? AND round_id=?',(u['id'],gid,rid)).fetchone()
    if not r:c.rollback();c.close();self.send_json(404,{'error':'UNKNOWN_ROUND'});return
    if r['status']=='SETTLED':
     bal=c.execute('SELECT balance FROM users WHERE id=?',(u['id'],)).fetchone()['balance'];c.commit();c.close();self.send_json(200,{'ok':True,'roundId':rid,'gameId':gid,'stake':r['stake'],'payout':r['payout'],'status':'SETTLED','balance':bal,'replayed':True});return
    if r['status']!='PENDING':c.rollback();c.close();self.send_json(409,{'error':'ROUND_NOT_PENDING'});return
    if payout>r['stake']*10000:c.rollback();c.close();self.send_json(409,{'error':'PAYOUT_ANOMALY'});return
    now=int(time.time());cur=c.execute('SELECT balance FROM users WHERE id=?',(u['id'],)).fetchone()['balance'];after=cur+payout
    c.execute('UPDATE users SET balance=?,last_active=? WHERE id=?',(after,now,u['id']))
    if payout>0:c.execute('INSERT INTO wallet_ledger(user_id,type,amount,balance_after,reference,created_at,idempotency_key) VALUES(?,?,?,?,?,?,?)',(u['id'],'WIN',payout,after,'win:'+str(r['id']),now,'win:'+str(r['id'])))
    c.execute("UPDATE game_rounds SET payout=?,status='SETTLED',settled_at=? WHERE id=? AND status='PENDING'",(payout,now,r['id']));c.commit();c.close();self.audit(u,'GAME_ROUND_SETTLE',gid+':'+rid);self.send_json(200,{'ok':True,'roundId':rid,'gameId':gid,'stake':r['stake'],'payout':payout,'status':'SETTLED','balance':after,'replayed':False});return
   except Exception:
    c.rollback();c.close();raise
  if p.startswith('/v1/games/') and p.endswith('/rounds/void'):
   u=self.require()
   if not u:return
   gid=p.split('/')[3];rid=str(q.get('roundId','')).strip();c=db();c.execute('BEGIN IMMEDIATE')
   try:
    r=c.execute('SELECT * FROM game_rounds WHERE user_id=? AND game_id=? AND round_id=?',(u['id'],gid,rid)).fetchone()
    if not r:c.rollback();c.close();self.send_json(404,{'error':'UNKNOWN_ROUND'});return
    if r['status']=='VOID':
     bal=c.execute('SELECT balance FROM users WHERE id=?',(u['id'],)).fetchone()['balance'];c.commit();c.close();self.send_json(200,{'ok':True,'roundId':rid,'gameId':gid,'stake':r['stake'],'payout':0,'status':'VOID','balance':bal,'replayed':True});return
    if r['status']!='PENDING':c.rollback();c.close();self.send_json(409,{'error':'ROUND_NOT_PENDING'});return
    now=int(time.time());cur=c.execute('SELECT balance FROM users WHERE id=?',(u['id'],)).fetchone()['balance'];after=cur+r['stake'];c.execute('UPDATE users SET balance=?,last_active=? WHERE id=?',(after,now,u['id']));c.execute('INSERT INTO wallet_ledger(user_id,type,amount,balance_after,reference,created_at,idempotency_key) VALUES(?,?,?,?,?,?,?)',(u['id'],'REFUND',r['stake'],after,'void:'+str(r['id']),now,'void:'+str(r['id'])));c.execute("UPDATE game_rounds SET status='VOID',settled_at=? WHERE id=? AND status='PENDING'",(now,r['id']));c.commit();c.close();self.audit(u,'GAME_ROUND_VOID',gid+':'+rid);self.send_json(200,{'ok':True,'roundId':rid,'gameId':gid,'stake':r['stake'],'payout':0,'status':'VOID','balance':after,'replayed':False});return
   except Exception:
    c.rollback();c.close();raise
  if p.startswith('/v1/games/') and p.endswith('/actions'):
   u=self.require();
   if not u:return
   gid=p.split('/')[3];action=str(q.get('action','')).strip();payload=q.get('payload') if isinstance(q.get('payload'),dict) else {}
   if not action or len(action)>64:self.send_json(400,{'error':'INVALID_ACTION'});return
   c=db();g=c.execute('SELECT id,enabled FROM games WHERE id=?',(gid,)).fetchone()
   if not g:c.close();self.send_json(404,{'error':'GAME_NOT_FOUND'});return
   if not g['enabled']:c.close();self.send_json(409,{'error':'GAME_DISABLED'});return
   now=int(time.time());eid=secrets.token_urlsafe(18);c.execute('INSERT INTO game_events(id,user_id,game_id,action,payload,created_at) VALUES(?,?,?,?,?,?)',(eid,u['id'],gid,action,json.dumps(payload,separators=(',',':')),now));c.commit();c.close();self.audit(u,'GAME_ACTION',gid+':'+action);self.send_json(200,{'accepted':True,'eventId':eid,'gameId':gid,'action':action,'serverTime':now});return
  # Admin group creation is POST.
  if p=='/v1/admin/user-groups':
   u=self.require_admin('MANAGE_USERS');
   if not u:return
   name=str(q.get('name','')).strip();desc=str(q.get('description',''));perms=q.get('permissions') if isinstance(q.get('permissions'),list) else []
   if not name:self.send_json(400,{'error':'INVALID_NAME'});return
   gid=str(q.get('id') or secrets.token_hex(8));now=int(time.time());c=db();c.execute('INSERT INTO user_groups VALUES(?,?,?,?,?,?)',(gid,name,desc,'ACTIVE',now,now));
   for pmt in perms:
    if str(pmt) in ADMIN_PERMISSIONS:c.execute('INSERT OR IGNORE INTO group_permissions VALUES(?,?)',(gid,str(pmt)))
   c.commit();c.close();self.audit(u,'ADMIN_GROUP_CREATE',gid);self.send_json(201,{'success':True,'id':gid});return
  self.send_json(404,{'error':'NOT_FOUND'})
 def do_PUT(self):
  p=urlparse(self.path).path
  try:q=self.body()
  except Exception:self.send_json(400,{'error':'INVALID_JSON'});return
  if online_features.handle(self,'PUT',p,q): return
  if p.startswith('/v1/admin/user-groups/') and p.endswith('/members'):
   u=self.require_admin('MANAGE_USERS');
   if not u:return
   gid=p.split('/')[4];ids=q.get('userIds') if isinstance(q.get('userIds'),list) else [];c=db();c.execute('BEGIN IMMEDIATE');c.execute('DELETE FROM group_members WHERE group_id=?',(gid,))
   for uid in ids:
    try:c.execute('INSERT OR IGNORE INTO group_members VALUES(?,?)',(gid,int(uid)))
    except Exception:pass
   c.commit();c.close();self.audit(u,'ADMIN_GROUP_MEMBERS',gid);self.send_json(200,{'success':True});return
  if p.startswith('/v1/admin/user-groups/'):
   u=self.require_admin('MANAGE_USERS');
   if not u:return
   gid=p.split('/')[4];c=db();g=c.execute('SELECT * FROM user_groups WHERE id=?',(gid,)).fetchone()
   if not g:c.close();self.send_json(404,{'error':'GROUP_NOT_FOUND'});return
   name=str(q.get('name',g['name'])).strip();desc=str(q.get('description',g['description']));status=str(q.get('status',g['status']));perms=q.get('permissions') if isinstance(q.get('permissions'),list) else None;now=int(time.time());c.execute('UPDATE user_groups SET name=?,description=?,status=?,updated_at=? WHERE id=?',(name,desc,status,now,gid))
   if perms is not None:
    c.execute('DELETE FROM group_permissions WHERE group_id=?',(gid,))
    for pmt in perms:
     if str(pmt) in ADMIN_PERMISSIONS:c.execute('INSERT OR IGNORE INTO group_permissions VALUES(?,?)',(gid,str(pmt)))
   c.commit();c.close();self.audit(u,'ADMIN_GROUP_UPDATE',gid);self.send_json(200,{'success':True});return
  self.send_json(404,{'error':'NOT_FOUND'})
 def do_DELETE(self):
  p=urlparse(self.path).path
  if p=='/v1/me':
   u=self.require()
   if not u:return
   c=db(); c.execute("UPDATE users SET status='DELETED' WHERE id=?",(u['id'],)); c.execute('DELETE FROM sessions WHERE user_id=?',(u['id'],)); c.commit(); c.close(); self.audit(u,'USER_DELETE'); self.send_json(200,{'ok':True}); return
  if p.startswith('/v1/admin/user-groups/'):
   u=self.require_admin('MANAGE_USERS')
   if not u:return
   gid=p.split('/')[4]; c=db(); c.execute('DELETE FROM group_permissions WHERE group_id=?',(gid,)); c.execute('DELETE FROM group_members WHERE group_id=?',(gid,)); c.execute('DELETE FROM user_groups WHERE id=?',(gid,)); c.commit(); c.close(); self.audit(u,'ADMIN_GROUP_DELETE',gid); self.send_json(200,{'success':True}); return
  self.send_json(404,{'error':'NOT_FOUND'})



if __name__=='__main__':
 init(); print('BetSimulator backend listening on %s:%d'%(HOST,PORT)); ThreadingHTTPServer((HOST,PORT),API).serve_forever()
